        <!-- jquery libarary -->
<script src="assets/vendor/jquery/jquery.min.js"></script>
        <!-- popper library -->
<script src="assets/vendor/popper.js/umd/popper.min.js"> </script>
        <!-- bootstrap library -->
<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
        <!-- the jquery cookie library  -->
<script src="assets/vendor/jquery.cookie/jquery.cookie.js"> </script>
        <!-- the cookie library  -->
<script src="assets/js/cookie.min.js"></script>
        <!-- sweetalert library -->
<script src="assets/js/sweetalert2.min.js"></script>
        <!-- jquery validate library -->
<script src="assets/js/jquery.validate.min.js"></script>
        <!-- jquery additional methods  -->
<script src="assets/js/additional-methods.min.js"></script>
        <!-- datatables js -->
<script src="assets/js/datatables.min.js"></script>
        <!-- datatables custome js -->
<script src="assets/js/custom.js"></script>
        <!-- front end js  -->
<script src="assets/js/front.js"></script>
        <!-- select2.min.js -->
<script src="assets/js/select2.full.min.js"></script>
<script src='assets/js/nprogress.js'></script>
<script src="middlewares/global.js?v=1"></script>
 <script src="assets/js/app-admin.js"></script> 
<script src="assets/js/virtual-select.min.js"></script>
