        <!-- jquery libarary -->
<script src="assets/vendor/jquery/jquery.min.js"></script>
        <!-- popper library -->
<script src="assets/vendor/popper.js/umd/popper.min.js"> </script>
        <!-- bootstrap library -->
<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
        <!-- the jquery cookie library  -->
<script src="assets/vendor/jquery.cookie/jquery.cookie.js"> </script>
        <!-- the cookie library  -->
<script src="assets/js/cookie.min.js"></script>
        <!-- sweetalert library -->
<script src="assets/js/sweetalert2.min.js"></script>
        <!-- jquery validate library -->
<script src="assets/js/jquery.validate.min.js"></script>
        <!-- jquery additional methods  -->
<script src="assets/js/additional-methods.min.js"></script>
        <!-- datatables js -->
<script src="assets/js/datatables.min.js"></script>
        <!-- datatables custome js
<script src="assets/js/custom.js"></script> -->
        <!-- front end js  -->
<script src="assets/js/front.js"></script>
        <!-- select2.min.js -->
<script src="assets/js/select2.full.min.js"></script>
<!-- nprogress -->
<script src='assets/js/nprogress.js'></script>
<!-- dropify -->
<script src='assets/js/dropify.min.js'></script>
<!-- pdf script -->
<!-- <script src='assets/js/pdf.html.js'></script> -->
<script src="assets/js/jspdf.umd.min.js"></script>
<script src="assets/js/html2canvas.min.js" ></script>
<script src="middlewares/user/global-user.js"></script>
<script src="assets/js/dataTables.searchPanes.min.js"></script>
<script src="assets/js/dataTables.select.min.js"></script>
<script src="assets/js/moment.min.js"></script>
<script src="assets/js/dataTables.dateTime.min.js"></script>
<script type="text/javascript" src="assets/js/jquery.tablesorter.min.js"></script>
<!-- <script src="assets/js/dark-mode-switch.min.js"></script> -->
<script src="assets/js/app.js"></script>
<script src="assets/js/virtual-select.min.js"></script>
