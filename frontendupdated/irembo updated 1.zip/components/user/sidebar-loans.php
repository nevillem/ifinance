<div id="sidebar" class="sidebar py-3">
  <div class="text-gray-400 text-uppercase px-3 px-lg-4 py-4 font-weight-bold small headings-font-family">MAIN</div>
  <ul class="sidebar-menu list-unstyled">
   
        <li id="links" class="sidebar-list-item"><a href="loans" class="sidebar-link text-muted
        <?php if($pagename === 'Dashboard'): ?>
         <?php echo 'active'; ?>
         <?php endif; ?>
         "><i class="o-home-1 mr-3 text-gray"></i><span>Dashboard</span></a></li>
    
        <li class="sidebar-list-item"><a href="members-loans" class="sidebar-link text-muted 
        <?php if($pagename === 'Accounts'): ?>
         <?php echo 'active'; ?>
         <?php endif; ?>">
        <i class="o-user-1 mr-3 text-gray "></i><span>Members <br>Accounts</span></a></li>
         
<!--Loans -->
<li class="sidebar-list-item">
  <a href="#" data-toggle="collapse" data-target="#expensepages" aria-expanded="false" aria-controls="pages" class="sidebar-link text-muted  <?php if($pagename === 'Loans'): ?>
    <?php echo 'active'; ?>
    <?php endif; ?>">
    <i class="o-wireframe-1 mr-3 text-gray"></i>
    <span>Loans</span></a>
    <div id="expensepages" class="collapse">
      <ul class="sidebar-menu list-unstyled border-left border-primary border-thick">
        <li class="sidebar-list-item" id="links"><a href="loans-application" class="sidebar-link text-muted pl-lg-5">Loan Application </a></li>
        <li class="sidebar-list-item" id="links"><a href="grouploan-application" class="sidebar-link text-muted pl-lg-5">Group Application </a></li>
        <!--<li class="sidebar-list-item" id="links"><a href="loanguarantors" class="sidebar-link text-muted pl-lg-5">Loan Guarantors </a></li>-->
        <!--<li class="sidebar-list-item" id="links"><a href="process-loans" class="sidebar-link text-muted pl-lg-5">Process Loans </a></li>-->
        <!--<li class="sidebar-list-item" id="links"><a href="approve-loans" class="sidebar-link text-muted pl-lg-5">Approve Loans</a></li>-->
        <!--<li class="sidebar-list-item" id="links"><a href="disburse-loans" class="sidebar-link text-muted pl-lg-5">Disburse Loans</a></li>-->
        <li class="sidebar-list-item" id="links"><a href="qualaterals-loans" class="sidebar-link text-muted pl-lg-5">Collaterals</a></li>
      </ul>
    </div>
  </li>
  <!--Loans end-->
        <li class="sidebar-list-item" id="loans-active-bar"><a href="loans-active" class="sidebar-link text-muted <?php if($pagename === 'Loans-Active'): ?>
         <?php echo 'active'; ?>
         <?php endif; ?>"><i class="o-statistic-1 mr-3 text-gray"></i><span>Active Loans</span></a></li>
  </ul>
  <div class="text-gray-400 text-uppercase px-3 px-lg-4 py-4 font-weight-bold small headings-font-family">EXTRAS</div>
  <ul class="sidebar-menu list-unstyled">
        <li class="sidebar-list-item"><a href="password-loans" class="sidebar-link text-muted  <?php if($pagename === 'Password'): ?>
         <?php echo 'active'; ?>
         <?php endif; ?>"><i class="o-database-1 mr-3 text-gray"></i><span>Password And Pin</span></a></li>
        <li class="sidebar-list-item"><a href="reports-loans" class="sidebar-link text-muted <?php if($pagename === 'Reports'): ?>
         <?php echo 'active'; ?>
         <?php endif; ?>"><i class="o-paperwork-1 mr-3 text-gray"></i><span>My Reports</span></a></li>
        <li class="sidebar-list-item"><a href="activity-loans" class="sidebar-link text-muted <?php if($pagename === 'Activity'): ?>
         <?php echo 'active'; ?>
         <?php endif; ?>"><i class="o-wireframe-1 mr-3 text-gray"></i><span>Activity Log</span></a></li>
  </ul>
</div>
