<?php

require_once('Functions/General-Functions.php');
$appName = 'iRembo Finance';
$date1 = date('F j, Y', time());
$date = date('F j, Y, g:i a', time());
$year = date('Y');
$month = date('F');
