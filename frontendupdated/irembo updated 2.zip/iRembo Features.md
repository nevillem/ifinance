iRembo Features
<!-- Super Admin Dashboard -->
*General Manager
1. Register SACCO (General Manager)
- KYC: Name,Email, Phone, Password, Confirm Password
2. Verification
- OTP sent to email
- OTP verification
3. Login
- Email, Password
- SACCO USSD code automatically generated
4. Branches
* General Manager creates Main branch
- Branch name, code, address, time stamp
- Add branch, Edit branch, Delete branch, View branch
*Edit Branch
- Status (Active/Inactive)
- Users can't login if status is Inactive
5. Users (General manager creates)
- Branch manager, Cashier, Loans officer, Agent
6. Reports
- View all brances
- View all Members
- View all users
- View all Accounts statements/ledger
- View all Transactions
- View income and expenditures
- Balance sheet
- Profit & Loss statement
- View loans report
- Journal 
7. Settings
*Loan settings
- Loan types
  - Intrest rates
  - Penalty rates
  - Lending capital*******
* Withdraw settings
- Minimum balance
- Withdraw charge
* Deposit settings
- 
* Expense & Income
- Expense category
- Income category
* Communication
- SMS notification
* Profile
- SACCO shortname
- Address
- Logo
* Accounts settings
- Account types
* Shares Setting
- Share value (price per share)

8. Accounts
*Individual
- Voluntary savings
- Compalsary savings
- Fixed savings
- Loans account
*Groups

9. Shares
- Register new share

10. User Roles
*Branch Manager
- Generate transaction reports
- Approves loans
- View live transactions
- Receives notifications
- Adds branch expenses
- Adds branch income
- Update password
- View shares

*Cashier
- Enroll members/ Create account
- Receives savings
- Makes withdraws
- Records shares
- Sets transaction PIN upon login
- Update password
- View live transactions

*Loans officer
- Loans applications
- View all loans (Pending, Active, rejected)
- Loan overdue notification

*Agent App
- Enroll members/ Create account
- Receive savings
- Makes withdraws
- View members enrolled
- Sets transaction PIN upon login
- Update password
- Loan application
- View live transactions

11. Transactions
- Savings
- Withdraws
- PIN
- Print receipt
- SMS



























