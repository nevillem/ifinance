<table class="table table-striped table-hover card-text" id="dataTables-example">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>Branch Name</th>
                        <th>Branch Code</th>
                        <th>Branch Status</th>
                        <th>Branch Address</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <th scope="row"></th>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td class="fw-100"></td>
                        <td class="fw-100"></td>
                          </tr>
                    </tbody>
                  </table>