<footer class="footer bg-white shadow align-self-end py-3 px-xl-5 w-100">
          <div class="container-fluid">
            <div class="row">
              <div class="col-md-6 text-center text-md-left text-secondary">
                <p class="mb-2 mb-md-0">iRembo Finance &copy; <span id="year"></span></p>
              </div>
              <div class="col-md-6 text-center text-md-right text-gray-400">
                <!-- <p class="mb-0">Powered by <a href="#" class="external text-gray-400">Mobitungo</a></p> -->
        <p class="mb-0"><span class="text-dark">Powered by</span> <a href="#" class="external text-warning">Mob<i class="fa fa-info-circle text-success" aria-hidden="true"></i>tungo</a></p>

              </div>
            </div>
          </div>
        </footer>
        <script>
                const d = new Date();
                let year = d.getFullYear();
                document.getElementById("year").innerHTML = year;
        </script>